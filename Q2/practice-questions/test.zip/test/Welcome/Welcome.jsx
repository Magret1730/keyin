import React from "react";

const Welcome = () => {
  return (
    <div>
      <button>Click me!</button>
      <h2>Welcome</h2>
      <h3>Thanks for visiting</h3>
    </div>
  );
};

export default Welcome;
